#ifndef __BSP_SSHAPE_H
#define __BSP_SSHAPE_H

#include "at32f413_wk_config.h"

typedef struct
{

	float Iq_start;
	float Iq_target;
	float Total_time;
	float RPM_target;
	float Pole_pairs;
  
	float w_target;
 
	float angle ;
	float Iq_out;
	float w_now;
	float done;
	uint16_t total_cnt;
	
}S_shape;

extern S_shape iopen;

void S_shapeInit(float V_start,float V_target,float Total_tim,float Rf_target,uint8_t Pole_pairs);
void Vf_control(void);
void If_control(void);

#endif /* __BSP_SSHAPE_H */


