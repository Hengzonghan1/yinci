#ifndef __FAST_MATH_H_
#define __FAST_MATH_H_

#define FS_CLAMP(x, lo, hi)  do { if ((x) < (lo)) (x) = (lo); else if ((x) > (hi)) (x) = (hi); } while (0)
#define FS_ABS(x)            ((x) >= 0.0f ? (x) : -(x))
#define FS_SIGN(x)           ((x) > 1e-6f ? 1.0f : ((x) < -1e-6f ? -1.0f : 0.0f))

#define _2_SQRT3  1.15470053838f
#define _SQRT3    1.73205080757f
#define _1_SQRT3  0.57735026919f
#define _SQRT3_2  0.86602540378f
#define _SQRT2    1.41421356237f
#define _120_D2R  2.09439510239f
#define _PI       3.14159265359f
#define _PI_2     1.57079632679f
#define _PI_3     1.0471975512f
#define _2PI_3    2.09439506f
#define _2PI      6.28318530718f
#define _3PI_2    4.71238898038f
#define _PI_6     0.52359877559f


float fast_sin(float x);
float fast_cos(float x);
void fast_sin_cos(float x, float *sin_x, float *cos_x);

#endif /* __FAST_MATH_H_ */
