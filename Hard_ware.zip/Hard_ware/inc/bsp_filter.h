#ifndef __BSP_FILTER_H
#define __BSP_FILTER_H


//������˹
typedef struct
{
	float states0;
	float states1;
	float b0;
	float b1;
	float b2;
	float a0;
	float a1;
	float a2;
	float gain0;
	float gain1;
}IIR_BUTTERWORTH_DEF;
extern IIR_BUTTERWORTH_DEF WE_IIR_LPF_Par;
extern float WE_IIR_LPF_Coeff[8];
extern float WE_IIR_LPF_Coeff_three[8];
extern float WE_IIR_LPF_Coeff_five[8];

void IirButterworthCoefficientInit(float temp[8], IIR_BUTTERWORTH_DEF *iir_butterworth_temp);
void IirButterworth(float in, float *out, IIR_BUTTERWORTH_DEF *iir_butterworth_temp);

#endif /* __BSP_FILTER_H */