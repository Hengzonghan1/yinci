#ifndef __FOC_H_
#define __FOC_H_

#include <math.h>
#include "stdint.h"

#define SQRT3_12 (0.1443375f)
#define SQRT3_13 (0.1332346f)
#define ts 1.0f

typedef struct{
    float u_d;
    float u_q;
    float u_alpha;
    float u_beta;
    float theta;

    float i_a;
    float i_b;
    float i_c;
  
    float i_alpha;
    float i_beta;
    float i_d;
    float i_q;

    float i_d_ref;
    float i_q_ref;

    float t_a;
    float t_b;
    float t_c;

    float sin;
    float cos;   
}FOC_t;

extern FOC_t foc;
void ClarkeTransf(FOC_t* foc);
void ParkTransf(FOC_t* foc);
void ParkInvTransf(FOC_t* foc);
void SVPWM(FOC_t* foc);


#endif /* __FOC_H_ */
