#ifndef __PID_H_
#define __PID_H_

#include "stdint.h"

typedef struct
{
	float Kp,Ki,Kd,Kb;

	float Out_Min;
	float Out_Max;

	float Points_limMin; 
	float Points_limMax; 

	float integrator,integrator_add;
	float prevError;			

	float out,prevOut;
	float differentiator,prevMeasurement;
  float tau;
	
	uint8_t flag;
}PID_t;
extern PID_t iq_pid;
extern PID_t id_pid;
extern PID_t smo_pll_pid;
extern PID_t smo2_pll_pid;
extern PID_t hfi_pid;
extern PID_t obser_pid;
extern PID_t speed_pid;
extern PID_t obser_ai_pid;
void PID_set(void);
float PID_Update(PID_t *pid, float setpoint, float measurement);
void PID_Init(PID_t *pid,float P,float I,float D,float B,float Points_lim,float Out_lim);
float PID_Speed_Update(PID_t *pid, float setpoint, float measurement);
#endif /* __PID_H_ */
