#ifndef __LOOP_H_
#define __LOOP_H_

#include "stdint.h"
typedef union 
{
		float    data_text[4];
		uint8_t  frame_tail[20];
}Frame_t;
extern Frame_t tx_frame;
void loop(float a,float b,float c,float d);

#endif /* __LOOP_H_ */
