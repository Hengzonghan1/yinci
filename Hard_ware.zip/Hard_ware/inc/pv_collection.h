#ifndef __PV_COLLECTION_H_
#define __PV_COLLECTION_H_

#include "at32f413_wk_config.h"
#include "foc.h"

typedef struct
{

	uint16_t offset_cnt;
	float offset_flag;

	float offset_buf[3];
	float adc_average_buf[3];
	float offset_Cen_value;
	float vref_bias[3];
	float f_hist_a[2];      /* i_a ȥë����ʷ */
	float f_hist_b[2];      /* i_b ȥë����ʷ */

}BiasCh_t;
extern BiasCh_t bv;
void Bias_Voltage(FOC_t *foc);
#endif /* __PV_COLLECTION_H_ */
