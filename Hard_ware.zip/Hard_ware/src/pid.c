#include "pid.h"
#include "bsp_customize.h"

PID_t iq_pid 			 = {0};
PID_t id_pid 			 = {0};
PID_t speed_pid    = {0};
PID_t smo_pll_pid  = {0};
PID_t smo2_pll_pid = {0};
PID_t hfi_pid      = {0};
PID_t obser_pid    = {0};
PID_t obser_ai_pid = {0};
void PID_set(void)
{
		PID_Init(&id_pid,     0.3f, 0.1f, 0,      0.000f, 4.5,  4.5);
		PID_Init(&iq_pid,     0.3f, 0.1f, 0,      0.000f, 4.5,  4.5);
		/* SMO PLL: ���Ϊ����ٶ�rad/s���޷�=omega_e_max(3000rpm*7�Լ���2200)
		   Kp/Ki��200rpm������֤������(��=0.707, ��n=150rad/s, E��0.56V):
		   Kp=2�Ʀ�n/E��380; PID������Ts����, Ki=��n?��Ts/E��4.0 */
		PID_Init(&smo_pll_pid, 60.0f, 0.2f, 0.0f, 0.000f, 2200.0f, 2200.0f);
		/* smo.c �۲���ר��PLL(����ʵ��, ������smo_sensorless������������Ⱦ)
		   EMF��ֵͬΪ��f����, �������� 60/0.2 */
		PID_Init(&smo2_pll_pid, 60.0f, 0.2f, 0.0f, 0.000f, 2200.0f, 2200.0f);
	  
//    PID_Init(&hfi_pid, 35.0f, 0.25f, 0, 0.000f, 200.0f,  200.0f);
    PID_Init(&hfi_pid, 157.0f, 1.1f, 0, 0.000f, 300.0f,  300.0f);

	  PID_Init(&obser_pid, 60.0f, 0.1f, 0, 0.0f, 500.0f, 500.0f);
	  /* ai_observer.c �����۲���PLL: PLL����Ѱ�������ֵ��һ��(sin���ȡ�[-1,1]),
	     �淶����: Kp=2�Ʀ�n��222(��n=157rad/s,��=0.707), Ki=��n?��Ts��2.5(��PID������Ts����)
	     ����޷�2200rad/s(��SMO PLLһ��), �����ٱ��Ͷ��Ƕ� */
	  PID_Init(&obser_ai_pid, 222.0f, 2.5f, 0, 0.0f, 1000.0f, 2200.0f);
		PID_Init(&speed_pid, 0.002f, 0.01f, 0, 0.0f, 4.5f, 4.5f);
}

void PID_Init(PID_t *pid,float P,float I,float D,float B,float Points_lim,float Out_lim)
{
	pid->Kp = P;
	pid->Ki = I;
	pid->Kd = D;
	pid->Kb = B;
	
	/* Clear controller variables */
	pid->integrator = 0.0f; //I���ۼ�
	pid->prevError  = 0.0f;

	pid->Points_limMin = -Points_lim;
	pid->Points_limMax = Points_lim;

	pid->Out_Min =  -Out_lim;
	pid->Out_Max =  Out_lim;
	pid->out     =  0.0f;
	pid->prevOut =  0;
	pid->differentiator = 0;
	pid->tau = 0.005f;
  pid->flag = 0;
}


float PID_Update(PID_t *pid, float setpoint, float measurement)
{
	  float error = setpoint - measurement;
	  if(pid->flag == 0)
		{
				pid->integrator    += pid->integrator_add + 0.5f* pid->Ki *(error + pid->prevError);
				pid->integrator_add = 0;
		}

		if(pid->integrator > pid->Points_limMax)
		{
			pid->integrator = pid->Points_limMax;
		}else if(pid->integrator < pid->Points_limMin)
		{
			pid->integrator = pid->Points_limMin;
		}
		
		//4
		pid->differentiator = 
		- (2.0f * pid->Kd * (measurement - pid->prevMeasurement)	/* Note: derivative on measurement, therefore minus sign in front of equation! */
		+ (2.0f * pid->tau - PWM_Ts) * pid->differentiator)
		/ (2.0f * pid->tau + PWM_Ts);
		
		pid->out      = pid->Kp *error + pid->integrator + pid->differentiator;
		if(pid->out > pid->Out_Max)
		{
			pid->out = pid->Out_Max;
			pid->flag = 1;
		}else if(pid->out < pid->Out_Min)
		{
			pid->out = pid->Out_Min;
		  pid->flag = 1;
		}else
		{
			pid->flag = 0;
		}

		pid->integrator_add  = (pid->out - pid->prevOut)*pid->Kb;
		pid->prevError       = error;
		pid->prevOut 				 = pid->out;
		pid->prevMeasurement = measurement;

		return pid->out;
}

float PID_Speed_Update(PID_t *pid, float setpoint, float measurement)
{
	  float error = setpoint - measurement;
	  if(pid->flag == 0)
		{
				pid->integrator    += pid->integrator_add + 0.0005f * pid->Ki *(error + pid->prevError);
				pid->integrator_add = 0;
		}

		if(pid->integrator > pid->Points_limMax)
		{
			pid->integrator = pid->Points_limMax;
		}else if(pid->integrator < pid->Points_limMin)
		{
			pid->integrator = pid->Points_limMin;
		}
		
		//4
		pid->differentiator = 
		- (2.0f * pid->Kd * (measurement - pid->prevMeasurement)	/* Note: derivative on measurement, therefore minus sign in front of equation! */
		+ (2.0f * pid->tau - PWM_Ts) * pid->differentiator)
		/ (2.0f * pid->tau + PWM_Ts);
		
		pid->out      = pid->Kp *error + pid->integrator + pid->differentiator;
		if(pid->out > pid->Out_Max)
		{
			pid->out = pid->Out_Max;
			pid->flag = 1;
		}else if(pid->out < pid->Out_Min)
		{
			pid->out = pid->Out_Min;
		  pid->flag = 1;
		}else
		{
			pid->flag = 0;
		}

		pid->integrator_add  = (pid->out - pid->prevOut)*pid->Kb;
		pid->prevError       = error;
		pid->prevOut 				 = pid->out;
		pid->prevMeasurement = measurement;

		return pid->out;
}











