#include "pv_collection.h"
#include "wk_adc.h"
#include "bsp_customize.h"
BiasCh_t bv = {0};

#if SPIKE_FILTER_EN
/* ��ȡ����ֵ�˲�: ��������խë��, ����ʵ����б����˥��, ������1���ӳ� */
static float SpikeFilter(float v, float hist[2])
{
	float a = hist[0], b = hist[1];
	float m = (a >= b) ? ((b >= v) ? b : ((a >= v) ? v : a))
	                   : ((a >= v) ? a : ((b >= v) ? v : b));
	hist[0] = v;
	hist[1] = a;
	return m;
}
#endif

void Bias_Voltage(FOC_t *foc)
{
	  //ƫ�õ�ѹ�ɼ�
		if(bv.offset_flag == 0)
		{


				if(bv.offset_cnt < 1024)
				{
					bv.adc_average_buf[0] += adc_preempt_conversion_data_get(ADC1, ADC_PREEMPT_CHANNEL_1);
					bv.adc_average_buf[1] += adc_preempt_conversion_data_get(ADC1, ADC_PREEMPT_CHANNEL_2);
					bv.adc_average_buf[2] += adc_preempt_conversion_data_get(ADC1, ADC_PREEMPT_CHANNEL_3);

				  bv.offset_cnt++;
				}else if(bv.offset_cnt >= 1024)
				{
					bv.adc_average_buf[0] /= 1024;
					bv.adc_average_buf[1] /= 1024;
					bv.adc_average_buf[2] /= 1024;

					bv.offset_Cen_value = (bv.adc_average_buf[0] + bv.adc_average_buf[1] + bv.adc_average_buf[2]) * 0.333f; //��λ��

					/* ƫ��ֵ: ��1024�ξ�ֵ���ͨ��ƫ��(ԭ�õ��β���,������) */
					bv.offset_buf[0] = bv.adc_average_buf[0] - bv.offset_Cen_value;
					bv.offset_buf[1] = bv.adc_average_buf[1] - bv.offset_Cen_value;
					bv.offset_buf[2] = bv.adc_average_buf[2] - bv.offset_Cen_value;

					bv.offset_flag = 1;
					bv.offset_cnt  = 0;

					TMR1->cctrl |=  CH123_EN_MASK; //��PWM
				}
		}else
		{
			bv.vref_bias[0] = (adc_preempt_conversion_data_get(ADC1, ADC_PREEMPT_CHANNEL_1) - bv.offset_buf[0] - bv.offset_Cen_value);//adc_buf[2] -
			bv.vref_bias[1] = (adc_preempt_conversion_data_get(ADC1, ADC_PREEMPT_CHANNEL_2) - bv.offset_buf[1] - bv.offset_Cen_value);//adc_buf[3] -
	    bv.vref_bias[2] = (adc_preempt_conversion_data_get(ADC1, ADC_PREEMPT_CHANNEL_3) - bv.offset_buf[2] - bv.offset_Cen_value);

#if SPIKE_FILTER_EN
			foc->i_a = SpikeFilter((3.3f * bv.vref_bias[0] / 4096) * 50, bv.f_hist_a);
			foc->i_b = SpikeFilter((3.3f * bv.vref_bias[1] / 4096) * 50, bv.f_hist_b);
#else
			foc->i_a=(3.3f * bv.vref_bias[0] / 4096) * 50;
			foc->i_b=(3.3f * bv.vref_bias[1] / 4096) * 50;
#endif
			//foc->i_c=(3.3f * bv.vref_bias[2] / 4096) * 50;

			foc->i_c = -(foc->i_a + foc->i_b);

		}
}

	