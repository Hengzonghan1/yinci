#include "bsp_filter.h"

IIR_BUTTERWORTH_DEF WE_IIR_LPF_Par;
float WE_IIR_LPF_Coeff[8]       = {1.0f, 2.0f, 1.0f, 1.0f, -1.8934f, 0.898859f, 0.0013487f, 1.0f}; 					// 120hz
float WE_IIR_LPF_Coeff_three[8] = {1.0f, 2.0f, 1.0f, 1.0f, -1.734725768f,0.766006600943f,0.0078202f, 1.0f}; // 300hz
float WE_IIR_LPF_Coeff_five[8]  = {1.0f, 2.0f, 1.0f, 1.0f, -1.561018f,0.6413515f,0.0200833f, 1.0f};         // 500hz


// ������˹�˲���
void IirButterworthCoefficientInit(float temp[8], IIR_BUTTERWORTH_DEF *iir_butterworth_temp)
{
  iir_butterworth_temp->b0 = temp[0];
  iir_butterworth_temp->b1 = temp[1];
  iir_butterworth_temp->b2 = temp[2];
  iir_butterworth_temp->a0 = temp[3];
  iir_butterworth_temp->a1 = temp[4];
  iir_butterworth_temp->a2 = temp[5];
  iir_butterworth_temp->gain0 = temp[6];
  iir_butterworth_temp->gain1 = temp[7];
  iir_butterworth_temp->states0 = 0.0f;
  iir_butterworth_temp->states1 = 0.0f;
}

void IirButterworth(float in, float *out, IIR_BUTTERWORTH_DEF *iir_butterworth_temp)
{
  float temp;
  temp = (iir_butterworth_temp->gain0 * in - iir_butterworth_temp->a1 *iir_butterworth_temp->states0) - 
	(iir_butterworth_temp->a2 * iir_butterworth_temp->states1);
  
	*out = ((iir_butterworth_temp->b0 * temp + iir_butterworth_temp->b1 * iir_butterworth_temp->states0) +
          iir_butterworth_temp->b2 * iir_butterworth_temp->states1)* iir_butterworth_temp->gain1;

  iir_butterworth_temp->states1 = iir_butterworth_temp->states0;
  iir_butterworth_temp->states0 = temp;
}



