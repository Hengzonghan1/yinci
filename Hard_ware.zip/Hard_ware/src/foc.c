#include "foc.h"
#include "fast_Math.h"
FOC_t foc = {0};
void ClarkeTransf(FOC_t* foc)
{
    foc->i_alpha = foc->i_a;
    foc->i_beta = (foc->i_a + 2 * foc->i_b) * 0.57735026919f;
}

void ParkTransf(FOC_t* foc)
{
    fast_sin_cos(foc->theta, &foc->sin, &foc->cos);
    foc->i_d = foc->i_alpha * foc->cos + foc->i_beta * foc->sin;
    foc->i_q = foc->i_beta * foc->cos - foc->i_alpha * foc->sin;
}

void ParkInvTransf(FOC_t* foc)
{
    foc->u_alpha = foc->u_d * foc->cos - foc->u_q * foc->sin;
    foc->u_beta = foc->u_q * foc->cos + foc->u_d * foc->sin;
}

void SVPWM(FOC_t* foc)
{
    foc->u_alpha *= (0.1332346f);
    foc->u_beta  *= (0.1332346f);
    float tmp1 = 0.8660254f * foc->u_alpha;
    float tmp2 = 0.5f * foc->u_beta;
    float u1 = foc->u_beta;
    float u2 = -tmp1 - tmp2;
    float u3 = tmp1 - tmp2;
    unsigned char sector = (u1 > 0.0f) | ((u2 > 0.0f) << 1) | ((u3 > 0.0f) << 2);
    float t1 = 0, t2 = 0;
    switch(sector)
		{
        case 1:  t1 = -u3; t2 = -u2; break;
        case 2:  t1 = -u1; t2 = -u3; break;
        case 3:  t1 = u1;  t2 = u2;  break;
        case 4:  t1 = -u2; t2 = -u1; break;
        case 5:  t1 = u3;  t2 = u1;  break;
        case 6:  t1 = u2;  t2 = u3;  break;
        default: foc->t_a = foc->t_b = foc->t_c = 0; return;
    }
    float sum = t1 + t2;
    if (sum > ts)
		{
        float k = ts / sum;
        t1 *= k;
        t2 *= k;
    }
    float t0 = (ts - t1 - t2) * 0.5f;
    switch (sector)
		{
        case 1:
            foc->t_a = t2 + t0;
            foc->t_b = t1 + t2 + t0;
            foc->t_c = t0;
            break;
        case 2:
            foc->t_a = t0;
            foc->t_b = t2 + t0;
            foc->t_c = t2 + t1 + t0;
            break;
        case 3:
            foc->t_a = t0;
            foc->t_b = t1 + t2 + t0;
            foc->t_c = t2 + t0;
            break;
        case 4:
            foc->t_a = t1 + t2 + t0;
            foc->t_b = t0;
            foc->t_c = t2 + t0;
            break;
        case 5:
            foc->t_a = t1 + t2 + t0;
            foc->t_b = t2 + t0;
            foc->t_c = t0;
            break;
        case 6:
            foc->t_a = t2 + t0;
            foc->t_b = t0;
            foc->t_c = t1 + t2 + t0;
            break;
    }
}













