#include "bsp_sshape.h"
#include "bsp_customize.h"
#include "foc.h"
#include "pid.h"
#include "fast_Math.h"

S_shape iopen;

void S_shapeInit(float Iq_start, float Iq_target, float Total_time, float RPM_target,uint8_t Pole_pairs)
{
    iopen.Iq_start   = Iq_start;    //0.5
    iopen.Iq_target  = Iq_target;   //2.5
    iopen.Total_time = Total_time;  //1s
    iopen.RPM_target = RPM_target;  //200rpm
    iopen.Pole_pairs = Pole_pairs;  //7

    iopen.w_target = (RPM_target / 60.0f) * Pole_pairs * _2PI; //w

    // ��ʼ״̬
    iopen.angle   = 0.0f;
    iopen.Iq_out  = Iq_start;
    iopen.w_now   = 0.0f;
    iopen.done    = 0;
	  iopen.total_cnt = (Total_time / PWM_Ts);
}

static uint16_t cnt = 0;
static float t      = 0;      // ��ǰ������ʱ��
static float t_norm = 0;      // ��һ��ʱ�� 0~1
static float k_s    = 0;      // S������ϵ��

void If_control(void)
{		
    if(iopen.done == 1)
    {
        iopen.angle += iopen.w_target*PWM_Ts;
        if(iopen.angle >= _2PI) iopen.angle -= _2PI;
			  else if(iopen.angle < 0) iopen.angle += _2PI;
        return;
    }else
		{
				t = (float)cnt * PWM_Ts;   //cnt����
				t_norm = t / iopen.Total_time;

				
				if(t_norm <= 0.5f)
				{
						k_s = 4.0f *t_norm *t_norm * t_norm;
				}else
				{
						k_s = 1.0f - 4.0f * (1.0f-t_norm)*(1.0f-t_norm)*(1.0f-t_norm);
				}

				if(k_s > 1.0f) k_s = 1.0f;
				if(k_s < 0.0f) k_s = 0.0f;

				iopen.Iq_out = iopen.Iq_start + (iopen.Iq_target - iopen.Iq_start) * k_s; //Iq
				iopen.w_now  = iopen.w_target * k_s;      														    //foc->Omega
				iopen.angle += iopen.w_now * PWM_Ts;      														    //foc->angle
				if(iopen.angle >= _2PI) iopen.angle -= _2PI;
				else if(iopen.angle < 0) iopen.angle += _2PI;
				
				if(cnt >= iopen.total_cnt)
				{
						iopen.done = 1;
						cnt = 0;
				}else
				{
						cnt++;
				}
		}
}

