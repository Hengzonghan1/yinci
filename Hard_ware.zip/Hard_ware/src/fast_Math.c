#include "fast_Math.h"

static float f1(float x)
{
  float u = 1.3528548e-10f;
  u = u * x + -2.4703144e-08f;
  u = u * x + 2.7532926e-06f;
  u = u * x + -0.00019840381f;
  u = u * x + 0.0083333179f;
  return u * x + -0.16666666f;
}

static float f2(float x)
{
  float u = 1.7290616e-09f;
  u = u * x + -2.7093486e-07f;
  u = u * x + 2.4771643e-05f;
  u = u * x + -0.0013887906f;
  u = u * x + 0.041666519f;
  return u * x + -0.49999991f;
}

float fast_sin(float x)
{
  // si = (int)(x / pi)
  int si = (int)(x * 0.31830988f);
  x = x - (float)si * _PI;
  if (si & 1) {
    x = x > 0.0f ? x - _PI : x + _PI;
  }
  return x + x * x * x * f1(x * x);
}

float fast_cos(float x)
{
  // si = (int)(x / pi)
  int si = (int)(x * 0.31830988f);
  x = x - (float)si * _PI;
  if (si & 1) {
    x = x > 0.0f ? x - _PI : x + _PI;
  }
  return 1.0f + x * x * f2(x * x);
}

void fast_sin_cos(float x, float *sin_x, float *cos_x)
{
  // si = (int)(x / pi)
  int si = (int)(x * 0.31830988f);
  x = x - (float)si * _PI;
  if (si & 1) {
    x = x > 0.0f ? x - _PI : x + _PI;
  }
  *sin_x = x + x * x * x * f1(x * x);
  *cos_x = 1.0f + x * x * f2(x * x);
}
