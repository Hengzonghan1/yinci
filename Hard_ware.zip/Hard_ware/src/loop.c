#include "loop.h"
#include "wk_usart.h"
#include "string.h"
#include "bsp_customize.h"

Frame_t tx_frame = {0};

void loop(float a,float b,float c,float d)
{
    tx_frame.data_text[0] = a;
		tx_frame.data_text[1] = b;
		tx_frame.data_text[2] = c;
		tx_frame.data_text[3] = d;
	
    tx_frame.frame_tail[16] = 0x00;
    tx_frame.frame_tail[17] = 0x00;
    tx_frame.frame_tail[18] = 0x80;
    tx_frame.frame_tail[19] = 0x7F;

    for(uint16_t i = 0; i < 20; i++)
    {
        usart_data_transmit(USART1, tx_frame.frame_tail[i]);
        while(usart_flag_get(USART1, USART_TDBE_FLAG) == RESET);
    }
    while(usart_flag_get(USART1, USART_TDC_FLAG) == RESET);
}




